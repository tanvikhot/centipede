 import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Hawk here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Hawk extends Actor
{
    /**
     * Act - do whatever the Hawk wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act(){ 
    int dx = 5;
    int dy = 5;
        // Add your action code here.
        move(dx);
        if(getX() + getImage().getWidth()/2 >= getWorld().getWidth()){
            turn(90);
            move(getImage().getHeight());
            dx = -dx;
       }
       if(getX() - getImage().getWidth()/2 <= 0){
           turn(-90);
            move(getImage().getHeight());
            dx = -dx;
       }
       //if(getY() > getWorld().getHeight()){
       //    turn(90);
        //   move(getImage().getHeight());
       //    dx = -dx;
      // }
      
    }
}
